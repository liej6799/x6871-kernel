#!/sbin/sh
# AnyKernel3 Kernel Installer
# X6871 | kernel 5.10.255-v1llhaze!-komari | MT6895
# Device: X6871 (MediaTek MT6895, GKI v4 boot image, A/B slots)

#################
# AnyKernel Properties
#################
kernel.string=X6871 | kernel 5.10.255-v1llhaze!-komari | MT6895
device.name=X6871
supported.versions=13,14,15
slot_handoff=true
is_kernel_install=true
is_slot_device=true
kernel.name=Image.gz

#################
# Initialization
#################
ui_print ""
ui_print "*****************************************************"
ui_print "  X6871 | kernel 5.10.255-v1llhaze!-komari"
ui_print "  MT6895 (GKI v4) | A/B slots"
ui_print "  Research-ROM"
ui_print "*****************************************************"
ui_print ""

# Check architecture
[ "$(getprop ro.product.cpu.abi)" != "arm64-v8a" ] && abort " Unsupported architecture: $(getprop ro.product.cpu.abi)"

# Check device
DEVICE=$(getprop ro.product.device)
[ "$DEVICE" != "X6871" ] && abort " Unsupported device: $DEVICE"
MODEL=$(getprop ro.product.model)
ui_print " Detected device: $DEVICE ($MODEL)"

# Detect block device pattern
if is_slot_device; then
  SLOT=$(getprop ro.boot.slot_suffix)
  case "$SLOT" in
    _a) BOOT_PART="boot_a" ;;
    _b) BOOT_PART="boot_b" ;;
    *)
      # Fallback: check which slot is active
      BOOT_PART="boot_a"
      ;;
  esac
  BLOCK="/dev/block/bootdevice/by-name/${BOOT_PART}"
  ui_print " Slot device detected: active slot=$SLOT → $BLOCK"
else
  BLOCK="/dev/block/bootdevice/by-name/boot"
  ui_print " Non-slot device: $BLOCK"
fi

[ ! -b "$BLOCK" ] && BLOCK="/dev/block/by-name/${BOOT_PART:-boot}"
[ ! -b "$BLOCK" ] && abort " Cannot find boot partition block device"
ui_print " Boot partition: $BLOCK"

# Ramdisk detection (not used for kernel-only, but kept for AK3 parity)
if [ -d /data/unencrypted ] || [ -d /metadata ]; then
  ramdisk_extract=true
else
  ramdisk_extract=false
fi

#######################
# Kernel Installation (kernel-only — no modules)
#######################
ui_print ""
ui_print " Flashing X6871 kernel (5.10.255-v1llhaze!-komari)…"

# GKI v4 boot image: the proven kernel is Image.gz (already compressed).
# We replace the kernel within the existing boot image so that ramdisk,
# DTB, and AVB metadata are preserved. The device keeps its stock
# vendor_dlkm modules (no module installation).
KERNEL_GZ="/tmp/anykernel/Image.gz"

[ ! -f "$KERNEL_GZ" ] && abort " Kernel image not found: $KERNEL_GZ"

ui_print " Dumping current boot image…"
BOOT_BAK="/tmp/anykernel/boot_current.img"
dd if="$BLOCK" of="$BOOT_BAK" 2>/dev/null
[ ! -s "$BOOT_BAK" ] && abort " Failed to dump boot partition"

# Repack boot image with new kernel (GKI v4)
ui_print " Repacking boot image with new kernel…"
NEW_BOOT="/tmp/anykernel/new_boot.img"

# Attempt to use mkbootimg for proper GKI v4 repack
if command -v mkbootimg >/dev/null 2>&1; then
  ui_print " Using mkbootimg for GKI v4 repack"
  TmpDir="/tmp/anykernel/boot_unpacked"
  mkdir -p "$TmpDir"

  # Unpack current boot image
  mkbootimg --unpack "$BOOT_BAK" -o "$TmpDir" 2>/dev/null || \
  unpackbootimg -i "$BOOT_BAK" -o "$TmpDir" 2>/dev/null || {
    ui_print " mkbootimg/unpackbootimg failed, falling back to direct flash"
    flash_image "$KERNEL_GZ" "$BLOCK"
    GOTO_END=1
  }

  if [ -z "$GOTO_END" ]; then
    # Replace kernel and repack
    mkbootimg --kernel "$KERNEL_GZ" \
      --ramdisk "$TmpDir/ramdisk.img" \
      --dtb "$TmpDir/dtbo.img" \
      --output "$NEW_BOOT" 2>/dev/null || {
        ui_print " Repack failed, falling back to direct flash"
        flash_image "$KERNEL_GZ" "$BLOCK"
      }
  fi
elif command -v magiskboot >/dev/null 2>&1; then
  ui_print " Using magiskboot for GKI v4 repack"
  magiskboot unpack "$BOOT_BAK" 2>/dev/null
  magiskboot repack --kernel "$KERNEL_GZ" --output "$NEW_BOOT" 2>/dev/null || \
  flash_image "$KERNEL_GZ" "$BLOCK"
fi

# If a new boot image was created, flash it
if [ -f "$NEW_BOOT" ] && [ -s "$NEW_BOOT" ]; then
  ui_print " Flashing repacked boot image…"
  flash_image "$NEW_BOOT" "$BLOCK"
else
  ui_print " Flashing kernel Image.gz directly…"
  flash_image "$KERNEL_GZ" "$BLOCK"
fi

# Flash DTB if provided (none for X6871 kernel-only)
if [ -f /tmp/anykernel/dtb/*.dtb ]; then
  ui_print " Flashing device tree..."
  for dtb in /tmp/anykernel/dtb/*.dtb; do
    ui_print " Found DTB: $(basename $dtb)"
  done
fi

# No modules installed (kernel-only; device uses stock vendor_dlkm)
ui_print ""
ui_print " Skipping module installation (kernel-only)"

# Ramdisk modifications (none for kernel-only)
if [ -d /tmp/anykernel/ramdisk ]; then
  ui_print " Applying ramdisk modifications..."
  :
fi

ui_print ""
ui_print "*****************************************************"
ui_print "  Installation complete!"
ui_print "  Reboot to apply changes."
ui_print "  X6871 | kernel 5.10.255-v1llhaze!-komari"
ui_print "*****************************************************"
ui_print ""
